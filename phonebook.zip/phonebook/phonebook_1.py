#Программа "телефонный справочник".
def work_with_phonebook():
    print('Телефонный справочник:')
    stop='No'
    choice=show_menu(stop)
    phone_book=read_txt('phonebook.txt')
    fields=['Фамилия', 'Имя', 'Телефон', 'Описание']
    while choice <=6:
        if choice==1:
            print_result(phone_book)
        elif choice==2:
            last_name=input('Введите Фамилию:')
            print(find_by_last-name(phone_book,last_name))
        elif choice==3:
            number=input('Введите номер телефона:900-')
            print(change_number(phone_book, number))
        elif choice==4:
            NewLastName=input('Введите фамилию:')
            NewName=input('Введите имя:')
            Newphone=input('Введите номер: 900-')
            print(add_by_lastname(phone_book,Newlastname, NewName, Newphone))
        elif choice == 5:
            save_phonebook('phonebook.txt')
        elif choice == 6:
            break
        else:
            print("Некорректный ввод. Попробуйте снова!")
        choice=show_menu(stop)
def show_menu(stop): 
    print("\n Выберите необходимое действие:\n"
        "1. Отобразить весь справочник\n"
        "2. Найти абонента по фамилии\n"
        "3. Найти абонента по номеру телефона\n"
        "4. Добавить абонента в справочник\n"
        "5. Сохранить справочник в текстовом формате\n"
        "6. Закончить работу")
def read_txt(phonebook):
    phone_book=[]
    fields=['Фамилия', 'Имя', 'Телефон', 'Описание']
    with open('phonebook.txt','r',encoding='utf-8') as phb:
        for line in phb:
            record = dict(zip(fields, line.rstrip ('\n').split(',')))
            phone_book.append(record)
    return phone_book
def print_result(phone_book):
    return phone_book
    choice=show_menu()

    while True:
        choice=show_menu()        
#filename= 'phonebook.txt'        
phone_book=read_txt('phonebook.txt')       
def write_txt(filename , phone_book):
    with open('phonebook.txt','w',encoding='utf-8') as phout:
        for i in range(len(phone_book)):
            s=''
            for v in phone_book[i].values():
                s+=v+','
    phout.write(f'{s[:-1]}\n')
work_with_phonebook()

