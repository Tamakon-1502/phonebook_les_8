#Домашка  "Телефонный справочник"
def work_with_phonebook():
    print('Телефонный справочник:')
try:
    with open('phonebook.txt', 'r', encoding='utf-8') as file:
        phonebook = file.read
except FileNotFoundError:
    phonebook = {}
def display_phonebook():
    print("Телефонный справочник:")
    for last_name, name, number in phonebook.items():
        print(f"{last_name} : {name} : {number}")
def find_contact_by_last_name(last_name):
    if last_name in phonebook:
        print(f"Найден абонент: {last_name} - {phonebook[name], [number]}")
    else:
        print(f"Абонент с фамилией {last_name} не найден")
def find_contact_by_number(number):
    for num in phonebook.items():
        if num == number:
            print(f"Найден абонент: {last_name}-{name}-{number}")
        else:
            print(f"Абонент с номером {number} не найден")
def add_contact(last_name, name, number):
    phonebook[last_name, name ] = number
    print(f"Абонент {last-name}-{name}- {number} успешно добавлен в справочник")
def save_phonebook():
    with open('phonebook.txt', 'w') as file:
        json.dump(phonebook, file)
    print("Справочник сохранен в файле phonebook.txt")
# Основной цикл программы
while True:
    print("\nВыберите необходимое действие:\n")
    print("1. Отобразить весь справочник")
    print("2. Найти абонента по фамилии")
    print("3. Найти абонента по номеру телефона")
    print("4. Добавить абонента в справочник")
    print("5. Сохранить справочник в текстовом формате")
    print("6. Закончить работу")

    choice = input("Выберите действие: ")
    if choice == "1":
        display_phonebook()
    elif choice == "2":
        last_name = input("Введите фамилию абонента: ")
        if last_name in phonebook:
            find_contact_by_name(last_name, name, number)
        else:
            print('Абонент с фамилией', last_name , 'не найден')
    elif choice == "3":
        number = input("Введите номер телефона: ")
        find_contact_by_number(number)
    elif choice == "4":
        name = input("Введите имя абонента: ")
        last_name = input("Введите фамилию абонента: ")
        number = input("Введите номер телефона: 900-")
        add_contact(last_name, name, number)
    elif choice == "5":
        save_phonebook()
    elif choice == "6":
        break
    else:
        print("Некорректный выбор. Попробуйте снова.")